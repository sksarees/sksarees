# Pevina - Saree E-Commerce Website Deployment Guide

This repository contains the front-end code for **Pevina.in**, an elegant e-commerce store designed for selling sarees. Since this is a static website (HTML, CSS, JS), you can easily host it for free using **GitHub Pages**.

## 1. Hosting on GitHub Pages

Follow these steps to upload your code and make your website live on GitHub:

1. **Create a GitHub Account:**
   If you don't have one, go to [github.com](https://github.com) and sign up.

2. **Create a New Repository:**
   - Click the **"+"** icon in the top right corner and select **"New repository"**.
   - Name your repository (e.g., `pevina-store`).
   - Choose **Public**.
   - Click **Create repository**.

3. **Upload the Files:**
   - In your new repository, click **"uploading an existing file"**.
   - Drag and drop all the files from the `pevina-store` folder (`index.html`, `styles.css`, and `script.js`).
   - Click **Commit changes** at the bottom.

4. **Enable GitHub Pages:**
   - In your repository, click on the **Settings** tab (the gear icon).
   - On the left sidebar, scroll down and click on **Pages**.
   - Under "Build and deployment" -> "Source", make sure **Deploy from a branch** is selected.
   - Under "Branch", change `None` to `main` (or `master`), then click **Save**.
   - Wait a couple of minutes. Refresh the page, and you will see a message at the top saying: *"Your site is live at https://[yourusername].github.io/pevina-store/"*.

---

## 2. Linking Your Custom Domain (`pevina.in`)

Now that your site is hosted on GitHub Pages, you need to connect your domain.

### In GitHub Settings:
1. Go back to **Settings > Pages** in your GitHub repository.
2. Scroll down to the **Custom domain** section.
3. Enter your domain: `pevina.in` (or `www.pevina.in`) and click **Save**.
   *(GitHub will automatically create a file called `CNAME` in your repository with your domain name).*
4. Once DNS is configured (see below), wait a few minutes, then check the **Enforce HTTPS** box to secure your site with an SSL certificate.

### In Your Domain Registrar (GoDaddy, Namecheap, Hostinger, etc.):
1. Log in to the company where you bought `pevina.in`.
2. Find the **DNS Management** or **DNS Settings** for your domain.
3. You need to create the following **A Records** pointing to GitHub's servers:

   | Type | Name / Host | Value / Points To |
   |------|-------------|-------------------|
   | A    | @           | 185.199.108.153   |
   | A    | @           | 185.199.109.153   |
   | A    | @           | 185.199.110.153   |
   | A    | @           | 185.199.111.153   |

4. To ensure `www.pevina.in` works as well, create a **CNAME Record**:

   | Type  | Name / Host | Value / Points To                        |
   |-------|-------------|------------------------------------------|
   | CNAME | www         | `[yourusername].github.io`               |

*(Note: DNS changes can take anywhere from 15 minutes to 24 hours to fully propagate worldwide).*

---

## 3. How the Store Works

- **No Backend Needed:** The cart data is saved in the user's browser (`localStorage`), making the site incredibly fast and completely free to host on GitHub.
- **WhatsApp Checkout:** When a user clicks "Order via WhatsApp," their cart is automatically formatted into a readable order message.
- **Update Your Number:** To receive orders, open `script.js`, find `const phoneNumber = "919876543210";` (Line 115), and replace it with your actual business WhatsApp number (include the country code `91` for India, but no `+` sign).

const products = [
    {
        id: 1,
        name: "Kanchipuram Pure Silk Saree",
        price: 15500,
        image: "https://images.unsplash.com/photo-1610189013444-933fb0122e23?auto=format&fit=crop&q=80&w=500"
    },
    {
        id: 2,
        name: "Banarasi Brocade Silk",
        price: 12000,
        image: "https://images.unsplash.com/photo-1583391733958-d25e07fac092?auto=format&fit=crop&q=80&w=500"
    },
    {
        id: 3,
        name: "Handwoven Chanderi Cotton",
        price: 4500,
        image: "https://images.unsplash.com/photo-1605915239019-3c3d526fb517?auto=format&fit=crop&q=80&w=500"
    },
    {
        id: 4,
        name: "Designer Georgette Saree",
        price: 6800,
        image: "https://images.unsplash.com/photo-1589465885857-44edb59bbff2?auto=format&fit=crop&q=80&w=500"
    },
    {
        id: 5,
        name: "Soft Linen Saree",
        price: 3200,
        image: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&q=80&w=500"
    },
    {
        id: 6,
        name: "Mysore Crepe Silk",
        price: 8900,
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&q=80&w=500"
    }
];

let cart = [];

// DOM Elements
const productsGrid = document.getElementById('products-grid');
const cartIcon = document.getElementById('cart-icon');
const cartModal = document.getElementById('cart-modal');
const closeCartBtn = document.getElementById('close-cart');
const cartItemsContainer = document.getElementById('cart-items');
const cartCount = document.getElementById('cart-count');
const cartTotalPrice = document.getElementById('cart-total-price');
const checkoutBtn = document.getElementById('checkout-btn');

// Initialize Store
function initStore() {
    renderProducts();
    loadCart();
}

// Render Products
function renderProducts() {
    productsGrid.innerHTML = '';
    products.forEach(product => {
        const productEl = document.createElement('div');
        productEl.classList.add('product-card');
        productEl.innerHTML = `
            <img src="${product.image}" alt="${product.name}" class="product-img">
            <div class="product-info">
                <h3 class="product-title">${product.name}</h3>
                <p class="product-price">₹${product.price.toLocaleString('en-IN')}</p>
                <button class="btn btn-add" onclick="addToCart(${product.id})">Add to Cart</button>
            </div>
        `;
        productsGrid.appendChild(productEl);
    });
}

// Add to Cart
function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    saveCart();
    updateCartUI();
    
    // Optional: Visual feedback
    cartIcon.style.transform = 'scale(1.2)';
    setTimeout(() => cartIcon.style.transform = 'scale(1)', 200);
}

// Remove from Cart
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    saveCart();
    updateCartUI();
}

// Update Cart UI
function updateCartUI() {
    // Update count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.innerText = totalItems;

    // Update items list
    cartItemsContainer.innerHTML = '';
    
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<p style="text-align:center; margin-top:20px; color:#666;">Your cart is empty.</p>';
    } else {
        cart.forEach(item => {
            const itemEl = document.createElement('div');
            itemEl.classList.add('cart-item');
            itemEl.innerHTML = `
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <div class="cart-item-title">${item.name}</div>
                    <div class="cart-item-price">₹${item.price.toLocaleString('en-IN')} x ${item.quantity}</div>
                </div>
                <button class="remove-item" onclick="removeFromCart(${item.id})"><i class="fas fa-trash"></i></button>
            `;
            cartItemsContainer.appendChild(itemEl);
        });
    }

    // Update total
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotalPrice.innerText = `₹${total.toLocaleString('en-IN')}`;
}

// Save & Load Cart (Local Storage)
function saveCart() {
    localStorage.setItem('pevinaCart', JSON.stringify(cart));
}

function loadCart() {
    const savedCart = localStorage.getItem('pevinaCart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
        updateCartUI();
    }
}

// Modal Toggle
cartIcon.addEventListener('click', () => {
    cartModal.classList.add('active');
});

closeCartBtn.addEventListener('click', () => {
    cartModal.classList.remove('active');
});

// Close modal when clicking outside content
cartModal.addEventListener('click', (e) => {
    if (e.target === cartModal) {
        cartModal.classList.remove('active');
    }
});

// Checkout via WhatsApp
checkoutBtn.addEventListener('click', () => {
    if (cart.length === 0) {
        alert("Your cart is empty!");
        return;
    }

    const phoneNumber = "919876543210"; // Replace with actual business WhatsApp number
    
    let message = "Hello Pevina, I would like to place an order:%0A%0A";
    
    cart.forEach((item, index) => {
        message += `${index + 1}. ${item.name} (x${item.quantity}) - ₹${(item.price * item.quantity).toLocaleString('en-IN')}%0A`;
    });
    
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    message += `%0A*Total Amount: ₹${total.toLocaleString('en-IN')}*%0A%0A`;
    message += "Please let me know the payment and delivery details.";

    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${message}`;
    window.open(whatsappUrl, '_blank');
});

// Run Init
initStore();